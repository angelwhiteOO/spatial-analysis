#' Function to obtain the Moran Scatterplot
#'
#' This function computes the Moran Scatterplot
#'
#'
#' @examples 
#'  using Data_USA, consider variable mental_health
#'  Moran.Scatterplot<-function(Data_USA$Variables$Mental_health,Data_USA$W)
#' @param X vector with the spatial atributs to be analysed
#' @param W matrix distances between spatial locations
#' @return Moran Scatterplot
#' @author Carles Comas \email{carles.comas@udl.cat}

#' @export

Moran.Scatterplot<-function(X,W){

if (!inherits(W, "matrix")) stop("W should be a matrix")
if (!inherits(X, "numeric")) stop("X should be a numeric value")
if (nrow(W)!=ncol(W)) stop("W should be a square matrix")
if(nrow(W)!=length(X)) stop("vector of atributs differs from distance matrix W")


Z<-c()
Z<-(X-mean(X))/sd(X)
n<-length(Z)
S0<-sum(W)
W_z<-c()
for(i in 1:n){
 W_z[i]<-0
 for(j in 1:n){
   W_z[i]<-W[i,j]*Z[j]+W_z[i]    
 }
}

A<-0
for(i in 1:n){
 for(j in 1:n){
  A<-A+W[i,j]*Z[i]*Z[j]              
   }
}

B<-sum(Z^2)

#####Moran I######
I<-n/S0*A/B 

xmax<-max(abs(min(Z)),max(Z))
xmin<-(-1)*xmax
ymax<-max(abs(min(W_z)),max(W_z))
ymin<-(-1)*ymax
x<-seq(xmin,xmax,0.05)
y<-I*x

plot(Z,W_z,pch=19,col="red",xlim=c(xmin,xmax),ylim=c(ymin,ymax))
abline(h=0,lwd=1,lty=2)
abline(v=0,lwd=1,lty=2)
lines(x,y,col="black")
lines(lowess(Z,W_z,f=0.2,iter=5,delta=0.02), col="green")
}


