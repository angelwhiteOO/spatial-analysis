#' Function to obtain the spatial weight matrix W
#'
#' This function computes the matrix of distances between centroids for states that share a common border line. Otherwise, this matrix element equals to zero
#'
#'
#' @param Spat_pol_data_frame is an object of class SpatialPolygonsDataFrame
#' @param Row_Stand defines if we want to obtain a row standarized distance matrix W. Default Row_Stand=TRUE
#' @return Matrix W
#' @author Carles Comas \email{carles.comas@udl.cat}

#' @import sp
#' @import rgeos
#' @import geosphere
#' @import spdep
#' @export

W_matrix <- function(Spat_pol_data_frame,Row_Stand=TRUE){

if (!inherits(Spat_pol_data_frame, "SpatialPolygonsDataFrame")) stop("Spat_pol_data_frame should be from class SpatialPolygonsDataFrame")


##Find centroids of each states
stat_cent <- sp::SpatialPointsDataFrame(rgeos::gCentroid(Spat_pol_data_frame, byid=TRUE), 
                                      us_states_cont@data, match.ID=FALSE)
####number of elements######
n<-length(Spat_pol_data_frame@data[[1]])

##Define coordinates (xc,yc) for each centroid######
xc<-stat_cent$x
yc<-stat_cent$y

#######Obtain the distance matrix (dist_w) of all states from centroids 
dist_w<-array(0,c(n,n))
dim(dist_w)=c(n,n)

for(i in 1:n){
 for(j in 1:n){
  dist_w[i,j]<-geosphere::distGeo(c(xc[[i]],yc[[i]]),c(xc[[j]],yc[[j]]))
 }
}

#########re-escale matrix to km##############3
dist_w<-dist_w/1000

neig<-spdep::poly2nb(Spat_pol_data_frame)

WI<-array(0,c(n,n))
dim(WI)=c(n,n)
for(i in 1:n){
   n2<-length(neig[[i]])
   for(i1 in 1:n){
     if(i != i1){
       for(j in 1:n2){
          if(i1==neig[[i]][j]){
           WI[i,i1]<-1
          }
       }
     }
  }
}


W<-array(0,c(n,n))
dim(W)=c(n,n)

for(i in 1:n){
 for(j in 1:n){
  W[i,j]<-WI[i,j]*dist_w[i,j]
 }
}

if(Row_Stand=="TRUE"){
W_red<-W
 for(i in 1:n){
   for(j in 1:n){
    W_red[i,j]<-W[i,j]/sum(W[i,])
   }
 }
W<-W_red
}
return(W)
}

