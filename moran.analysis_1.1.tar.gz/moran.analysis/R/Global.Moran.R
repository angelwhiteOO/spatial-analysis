#' Function to obtain the global Moran'I statistics
#'
#' This function computes the global Moran'I statistics. Pseudp-p-value is based on a permutation approach for nsim simulations of spatial patterns where the spatial atributes are randomly permuted over fixed spatial locations
#'
#'
#' @examples 
#'  using Data_USA, consider variable mental_health
#'  Global.Moran<-function(Data_USA$Variables$Mental_health,Data_USA$W,999,seed=789898)
#'  
#' @param X vector with the spatial atributs to be analysed
#' @param W matrix distances between spatial locations
#' @param nsim number of permutations to obtain a pseudo-p-value
#' @param seed value for the permutations, set.seed(seed)
#' @return Moran's I, expected Moran's I under independence and p-value
#' @author Carles Comas \email{carles.comas@udl.cat}

#' @export

Global.Moran<-function(X,W,nsim,seed){

if (!inherits(W, "matrix")) stop("W should be a matrix")
if ((nsim%%1==0)=="FALSE") stop("nsim should be an integer number")
if (!inherits(X, "numeric")) stop("X should be a numeric value")
if (missing(seed)) seed<-round(runif(1,0,1)*100000,0)
if (nrow(W)!=ncol(W)) stop("W should be a square matrix")
if(nrow(W)!=length(X)) stop("vector of atributs differs from distance matrix W")

set.seed(seed)
Z<-c()
Z<-(X-mean(X))/sd(X)
I_per<-c()
n<-length(Z)
S0<-sum(W)

###########Global Moran's I################
A<-0
for(i in 1:n){
 for(j in 1:n){
  A<-A+W[i,j]*Z[i]*Z[j]              
   }
}

B<-sum(Z^2)

#####Moran I######
I<-round(n/S0*A/B ,6)

#####Expected Moran's I under independence#######
EI<-round(-1/(n-1),6)

####Compte p-value based on nsim random permutations##################
Z1<-sample(Z,n,replace=F)

for(i1 in 1:nsim){
 Z1<-sample(Z,n,replace=F)
 A<-0
 for(i in 1:n){
   for(j in 1:n){
    A<-A+W[i,j]*Z1[i]*Z1[j]                  
   }
 }
 B<-sum(Z1^2)
 I_per[i1]<-n/S0*A/B
}

prob<-1-mean(I_per<I)
pval<-pval_one_q(prob)
pval<-round(pval[[1]],6)
result<-list("Moran_I"=I,"Expected_Moran_I"=EI,"p_value"=pval)

cat(paste("","\n","#######################################","\n", "        Global Moran's I analysis","\n","#######################################","\n",
"","\n","Moran's I", "=", I, "\n", "Expected Moran's", "=", EI, "\n", "p_value","=",pval,"\n",
"","\n",
"Type I$Moran_I to obtain the Global Moran's I", "\n",
"Type I$Expected_Moran_I to obtain the Expected Global Moran's I", "\n",
"Type I$p_value to obtain the p-value for the Global Moran's I", "\n",
"", "\n",
collapse = NULL)) 
invisible(return(result))
}


