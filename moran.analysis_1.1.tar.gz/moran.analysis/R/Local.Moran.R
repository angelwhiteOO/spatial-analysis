#' Function to obtain the local Moran'I statistics
#'
#' This function computes the local Moran'I statistics. Pseudp-p-value are based on a permutation approach for nsim simulations of spatial patterns where the spatial atributes are randomly permuted over fixed spatial locations
#'
#'
#' @examples 
#'  using Data_USA, consider variable mental_health
#'  Local.Moran<-function(Data_USA$Variables$Mental_health,Data_USA$W,999,seed=789898)
#'
#' @param X vector with the spatial atributs to be analysed
#' @param W matrix distances between spatial locations
#' @param nsim number of permutations to obtain a pseudo-p-value
#' @param seed value for the permutations, set.seed(seed)
#' @return local Moran's I and  related p-values
#' @author Carles Comas \email{carles.comas@udl.cat}

#' @export


Local.Moran<-function(X,W,nsim,seed){

if (!inherits(W, "matrix")) stop("W should be a matrix")
if ((nsim%%1==0)=="FALSE") stop("nsim should be an integer number")
if (!inherits(X, "numeric")) stop("X should be a numeric value")
if(missing(seed)) seed<-round(runif(1,0,1)*100000,0)
if (nrow(W)!=ncol(W)) stop("W should be a square matrix")
if(nrow(W)!=length(X)) stop("vector of atributs differs from distance matrix W")


set.seed(seed)
Z<-c()
Z<-(X-mean(X))/sd(X)
n<-length(Z)

I_loc<-c()

for(i in 1:n){ 
A<-0

 for(j in 1:n){
   A<-A+W[i,j]*Z[j]                            
 }
   A<-A*Z[i]

   B<-sum(Z^2)
 
   I_loc[i]<-A/B 
}

I_per_loc=array(10,c(n,nsim))
dim(I_per_loc)=c(n,nsim)

for(j1 in 1:n){
 for(i1 in 1:nsim){
    Z1<-sample(Z[-j1],n-1,replace=F)
    Z11<-c()
    count<-0

     for(i in 1:n){
      count<-count+1
      Z11[i]<-Z1[count]
       if(i==j1){
        Z11[i]<-Z[j1]
        count<-count-1
       }
     }  

    Z1<-Z11

  A<-0

   for(i in 1:n){
    A<-A+W[i,j1]*Z1[i] 
   }

   A<-A*Z1[j1]
   B<-sum(Z1^2)
 
   I_per_loc[j1,i1]<-A/B
 }
}

pvalI_loc<-c()
for(i in 1:n){
pvalI_loc[i]<-1-mean(I_per_loc[i,]<I_loc[i])
prob<-pvalI_loc[i]
pval<-pval_one_q(prob)
pvalI_loc[i]<-pval[[1]]
}

PLI<-round(pvalI_loc,8)
I_loc<-round(I_loc,8)

result<-list("Local_Moran_I"=I_loc,"p_values"=PLI)
cat(paste("","\n","#######################################","\n", "        Local Moran's I analysis","\n","#######################################","\n",
"","\n",
"Type LI$Local_Moran to obtain the Local Moran's I", "\n",
"Type LI$p_values to obtain the p-values for the Local Moran's I", "\n",
"", "\n",
collapse = NULL)) 
invisible(return(result))
}


