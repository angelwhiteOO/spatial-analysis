#' Function to obtain the p-value of one tailed test
#'
#' This function computes the p-value for one tailed test
#'
#'
#' @param a probabilit value

#' @return p-value
#' @author Carles Comas \email{carles.comas@udl.cat}


#' @export

pval_one_q<-function(prob){
if (!inherits(prob, "numeric")) stop("prob should be a number")
if(prob<0 | prob>1) stop("prob should be larger than 0 and smaller or equal to 1")
  if(prob>0.5){
   pval<-1-prob
  }
if(prob<=0.5){
   pval<-prob
  } 
  result<-list(pval)
  invisible(return(result))  
}




